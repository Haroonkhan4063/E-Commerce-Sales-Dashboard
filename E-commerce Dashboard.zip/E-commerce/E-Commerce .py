import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from pathlib import Path


DATA_PATH = Path(r"D:\Python lib\Projects\E-commerce.csv")
OUTPUT_IMAGE = "E_Commerce_Dashboard_Pro.png"


def load_and_prepare_data(file_path: Path) -> pd.DataFrame:
    df = pd.read_csv(file_path, encoding="ISO-8859-1")
    df.dropna(subset=["CustomerID"], inplace=True)
    df = df[(df["Quantity"] > 0) & (df["UnitPrice"] > 0)]
    df["InvoiceDate"] = pd.to_datetime(df["InvoiceDate"])
    df["TotalSales"] = df["Quantity"] * df["UnitPrice"]
    df["Month"] = df["InvoiceDate"].dt.to_period("M")
    return df


def prepare_aggregates(df: pd.DataFrame):
    monthly_sales = df.groupby("Month")["TotalSales"].sum()

    country_sales = (
        df.groupby("Country")["TotalSales"]
        .sum()
        .sort_values(ascending=False)
        .head(10)
    )

    top_products = (
        df.groupby("Description")["Quantity"]
        .sum()
        .sort_values(ascending=False)
        .head(10)
    )

    return monthly_sales, country_sales, top_products


def create_dashboard(monthly_sales, country_sales, top_products):
    fig = plt.figure(figsize=(15, 10))
    fig.suptitle(
        "E-Commerce Sales Analysis Dashboard",
        fontsize=20,
        fontweight="bold",
        color="#333333"
    )

    ax1 = plt.subplot(2, 2, 1)
    monthly_sales.plot(
        kind="line",
        marker="o",
        linewidth=2,
        color="royalblue",
        ax=ax1
    )
    ax1.set_title("Monthly Sales Trend", fontsize=12, fontweight="bold")
    ax1.set_xlabel("Month")
    ax1.set_ylabel("Sales ($)")
    ax1.grid(True, linestyle="--", alpha=0.5)

    ax2 = plt.subplot(2, 2, 2)
    ax2.bar(country_sales.index, country_sales.values, color="tomato")
    ax2.set_title("Top 10 Countries by Revenue", fontsize=12, fontweight="bold")
    ax2.set_xlabel("Country")
    ax2.set_ylabel("Sales ($)")
    plt.setp(ax2.get_xticklabels(), rotation=45, ha="right")
    ax2.grid(axis="y", linestyle="--", alpha=0.5)

    ax3 = plt.subplot(2, 1, 2)
    y_pos = np.arange(len(top_products))
    ax3.barh(y_pos, top_products.values, color="seagreen")
    ax3.set_yticks(y_pos)
    ax3.set_yticklabels(top_products.index)
    ax3.invert_yaxis()
    ax3.set_title("Top 10 Best Selling Products", fontsize=12, fontweight="bold")
    ax3.set_xlabel("Quantity Sold")

    plt.tight_layout(rect=[0, 0.03, 1, 0.95])
    plt.savefig(OUTPUT_IMAGE, dpi=300, bbox_inches="tight")
    plt.show()

    print(f"Dashboard saved successfully as '{OUTPUT_IMAGE}'")


def main():
    df = load_and_prepare_data(DATA_PATH)
    monthly_sales, country_sales, top_products = prepare_aggregates(df)
    create_dashboard(monthly_sales, country_sales, top_products)


if __name__ == "__main__":
    main()
